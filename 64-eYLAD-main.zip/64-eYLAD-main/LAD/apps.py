from django.apps import AppConfig


class LadConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'LAD'

    def ready(self):
        import LAD.signals