task_0="""login_count,elsiLab,year,otherComp,sub_ros,sub_ip,sub_emb_c,sub_ml,sub_ap,sub_cs,sub_mss,sub_fpga,sub_mm,sub_de"""

task_1 = """login_count,rateTask,rateUsefulness,rateResource,
rateSelfKnowledgeBefore,rateSelfKnowledgeAfter,task0_marks,task0_penalty,days_online,posts,[answers,edits to answers,followups,replies to followups]
"""
task_2 = """login_count,rateTask1,rateTask1Design,rateSelfContribution,rateResource,
rateDifficulty,rateLiveSessionUsefulness,task0_marks,task0_penalty,task1_marks,task1_penalty,days_online,posts,[answers,edits to answers,followups,replies to followups]
"""
task_3 = """login_count,rateskills,rateThemeDesign,rateWork,covidCase,rateDifficulty,rateLiveSessionUsefulness,[rateMyPerformance,rateMyLearning,rateMyFocus,rateStressLevel,rateWorkManagement],
[rateTask2,rateTask2Design,rateSelfContribution,rateResource],
[ratetheme, rateProblemStatement,rateKnowledgeOfPreviousTask, rateInstructorResponse, rateStudentResponse],task0_marks,task0_penalty,task1_marks,task1_penalty,task2_marks,task2_penalty
,days_online,posts,[answers,edits to answers,followups,replies to followups]
"""
task_4 = """login_count,rateskills,rateThemeDesign,rateWork,teamorindividual,
rateDifficulty,rateLiveSessionUsefulness,[rateMyPerformance,rateMyLearning,rateMyFocus,rateStressLevel,rateWorkManagement],
[rateTask3,rateTask3Design,rateSelfContribution,rateResource],
[ratetheme, rateProblemStatement,rateKnowledgeOfPreviousTask, rateInstructorResponse, rateStudentResponse],task1_marks,task1_penalty,task2_marks,task2_penalty
,task3_marks,task3_penalty
,days_online,posts,[answers,edits to answers,followups,replies to followups]
"""
task_5 = """login_count,rateskills,rateThemeDesign,rateWork,
rateDifficulty,rateLiveSessionUsefulness,[rateMyPerformance,rateMyLearning,rateMyFocus,rateStressLevel,rateWorkManagement],
[rateTask4,rateTask4Design,rateSelfContribution,rateResource],
[ratetheme, rateProblemStatement,rateKnowledgeOfPreviousTask, rateInstructorResponse, rateStudentResponse],task1_marks,task1_penalty,task2_marks,task2_penalty
,task3_marks,task3_penalty,task4_marks,task4_penalty
,days_online,posts,[answers,edits to answers,followups,replies to followups]
"""
task_6 = """login_count,rateskills,rateThemeDesign,rateWork,teamorindividual,
rateDifficulty,rateLiveSessionUsefulness,[rateMyPerformance,rateMyLearning,rateMyFocus,rateStressLevel,rateWorkManagement],
[rateTask5,rateTask5Design,rateSelfContribution,rateResource],
[ratetheme, rateProblemStatement,rateKnowledgeOfPreviousTask, rateInstructorResponse, rateStudentResponse],task2_marks,task2_penalty
,task3_marks,task3_penalty,task4_marks,task4_penalty,task5_marks,task5_penalty
,days_online,[posts,answers,edits to answers,followups,replies to followups]
"""
